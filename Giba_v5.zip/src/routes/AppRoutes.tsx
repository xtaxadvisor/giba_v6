import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AdminPortal from '../pages/admin/AdminPortal';
import ClientPortal from '../pages/client/ClientPortal';
import InvestorPortal from '../pages/investor/InvestorPortal';
import ProfessionalPortal from '../pages/professional/ProfessionalPortal';
import StudentPortal from '../pages/student/StudentPortal';
import NotFoundPage from '../components/shared/NotFoundPage';
import { investorvideos } from '@/components/investor/VideoLibrary';

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/client" replace />} />
      <Route path="/admin/*" element={<AdminPortal />} />
      <Route path="/client/*" element={<ClientPortal />} />
      <Route path="/investor/*" element={<InvestorPortal videos={investorvideos} />} />
      <Route path="/professional/*" element={<ProfessionalPortal />} />
      <Route path="/student/*" element={<StudentPortal />} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}