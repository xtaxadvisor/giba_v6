import { useNotificationStore } from '../lib/store';

export const TWILIO_CONFIG = {
  accountSid: 'AC82a9b0af15453bf1e139bd4b0b590de2',
  authToken: '273edc542da0b777b9652afa972aedfe',
  phoneNumber: '+13212390386',
  whatsappNumber: '+14155238886',
  messagingServiceSid: 'SK682ca9611841794a8f5524e5b7539a38'
};

// Validate Twilio configuration
export const validateTwilioConfig = () => {
  const required = [
    'accountSid',
    'authToken',
    'phoneNumber'
  ];

  const missing = required.filter(key => !TWILIO_CONFIG[key as keyof typeof TWILIO_CONFIG]);

  if (missing.length > 0) {
    console.error('Missing Twilio configuration:', missing);
    useNotificationStore.getState().addNotification(
      'Communication services configuration incomplete',
      'error'
    );
    return false;
  }

  return true;
};