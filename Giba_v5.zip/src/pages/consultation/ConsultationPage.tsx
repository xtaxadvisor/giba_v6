import ConsultationForm from '@/components/consultation/ConsultationForm';

export default function ConsultationPage() {
  return (
    <main className="py-10 px-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Book a Consultation</h1>
<ConsultationForm 
  onSubmit={(data) => {
    console.log('Form submitted:', data);
  }} 
  onCancel={() => {
    console.log('Form cancelled');
  }} 
/>
    </main>
  );
}