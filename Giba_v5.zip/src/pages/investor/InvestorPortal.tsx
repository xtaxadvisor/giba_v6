import React from 'react';
import VideoLibraryProps from '../../components/video/VideoList'; // Assuming types are defined in a separate file

export interface VideoLibraryProps {
  videos: { id: number; title: string; url: string }[];
}

export function VideoLibrary({ videos }: VideoLibraryProps): JSX.Element {
  return (
    <div>
      {videos.map((video: { id: number; title: string; url: string }) => (
      <div key={video.id}>
        <h3>{video.title}</h3>
        <a href={video.url}>Watch</a>
      </div>
      ))}
    </div>
  );
}

export default VideoLibrary;
