import React from 'react';

export default function InvestmentOpportunities() {
  return (
    <div className="investment-opportunities">
      <h1>Investment Opportunities</h1>
      <p>Explore available investment options here.</p>
      {/* TODO: Fetch and render a list of opportunities */}
    </div>
  );
}
