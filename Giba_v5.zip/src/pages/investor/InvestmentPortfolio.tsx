import React from 'react';

export default function InvestmentPortfolio() {
  return (
    <div className="investment-portfolio">
      <h1>Investment Portfolio</h1>
      <p>Here you can view and manage your investments.</p>
      {/* TODO: Add portfolio chart and details */}
    </div>
  );
}
