import React from 'react';

export default function InvestmentPerformance() {
  return (
    <div>
      <h1>Investment Performance</h1>
      <p>Performance charts and data will appear here.</p>
    </div>
  );
}
