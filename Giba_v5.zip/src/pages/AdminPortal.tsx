import { Outlet } from 'react-router-dom';
import { AdminLayout } from '../components/admin/AdminLayout';

/**
 * AdminPortal
 * This component wraps the entire admin section of the application.
 * It uses <Outlet /> to render nested routes defined in AppRoutes.tsx.
 * AdminLayout provides the shared layout structure (sidebar, header, etc).
 */
export default function AdminPortal() {
  return (
    <AdminLayout>
      <Outlet />
    </AdminLayout>
  );
}