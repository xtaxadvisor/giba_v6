import { Link } from 'react-router-dom';
import type { MenuItem } from '../../../types';

interface AdminSidebarProps {
  menuItems: MenuItem[];
  currentPath: string;
}

export function AdminSidebar({ menuItems, currentPath }: AdminSidebarProps) {
  if (!menuItems || menuItems.length === 0) {
    return (
      <aside className="w-64 bg-white h-[calc(100vh-4rem)] border-r border-gray-200 fixed flex items-center justify-center">
        <p className="text-sm text-gray-500">No menu available</p>
      </aside>
    );
  }

  return (
    <aside className="w-64 bg-white h-[calc(100vh-4rem)] border-r border-gray-200 fixed">
      <nav className="mt-5 px-2" role="navigation" aria-label="Admin sidebar">
        {menuItems.map((item) => {
          const isActive = currentPath === item.href;
          return (
            <Link
              key={item.href}
              to={item.href}
              className={`group flex items-center px-2 py-2 text-base font-medium rounded-md mb-1
                ${isActive 
                  ? 'bg-red-50 text-red-600' 
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                }`}
            >
              <item.icon className={`mr-4 h-6 w-6 ${isActive ? 'text-red-600' : 'text-gray-400'}`} />
              {item.title}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}