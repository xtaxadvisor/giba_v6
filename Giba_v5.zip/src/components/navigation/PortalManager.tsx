import { useAuth } from '../../contexts/AuthContext';
import { useNotificationStore } from '../../lib/store';
import { getAvailablePortals } from '../../services/navigation/portalConfig';

export function usePortalManager() {
  const { user, isAuthenticated } = useAuth();
  const { addNotification } = useNotificationStore();

  console.log('[PortalAccess] User:', user);

  const checkPortalAccess = (portalId: string): boolean => {
    const config = getPortalConfig(portalId);
    if (!config) {
      console.warn(`[checkPortalAccess] Config not found for portalId: ${portalId}`);
      return false;
    }
    if (import.meta.env.DEV) return true;
    return isAuthenticated;
  };

  const handlePortalAccess = (
    portalId: string
  ): { canAccess: boolean; redirectPath?: string } => {
    const config = getPortalConfig(portalId);
    if (!config) {
      addNotification('Portal not found', 'error');
      return { canAccess: false };
    }

    // ✅ DEV mode shortcut
    if (import.meta.env.DEV) {
      console.log(`[DevMode] Bypassing access checks for ${portalId}`);
      return { canAccess: true };
    }

    if (!isAuthenticated) {
      return {
        canAccess: false,
        redirectPath: `/login?redirect=${portalId}`,
      };
    }

    return { canAccess: true };
  };

  return {
    checkPortalAccess,
    handlePortalAccess,
  };
}
function getPortalConfig(portalId: string) {
  const availablePortals = getAvailablePortals();
  return availablePortals.find((portal) => portal.id === portalId) || null;
}
