import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Users, Database, TrendingUp, MessageSquare, BookOpen } from 'lucide-react';
import { Button } from '../ui/Button';
import { useAuth } from '../../contexts/AuthContext';
import { useNotificationStore } from '../../lib/store';
import { startTransition } from 'react';
import { PORTAL_CONFIGS } from '../../services/navigation/portalConfig';

interface PortalButtonProps {
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  path: string;
}

function PortalButton({ title, description, icon: Icon, path }: PortalButtonProps) {
  let user, isAuthenticated;
  try {
    const auth = useAuth();
    user = auth.user;
    isAuthenticated = auth.isAuthenticated;
  } catch (err) {
    console.warn('useAuth called outside of AuthProvider');
    return null;
  }
  const { addNotification } = useNotificationStore();
  const navigate = useNavigate();

  const handleAccess = () => {
    try {
      if (!isAuthenticated) {
        navigate('/login', { state: { from: path } });
        return;
      }

      if (!user?.role) {
        console.warn(`User role not yet available for "${title}". Access temporarily blocked.`);
        addNotification('Authentication is still loading. Please try again shortly.', 'error');
        return;
      }

      startTransition(() => {
        navigate(path);
      });
    } catch (err) {
      console.error('Navigation failed:', err);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div className="flex items-center mb-4">
        <div className="p-2 bg-blue-50 rounded-lg">
          {React.createElement(Icon, { className: "h-6 w-6 text-blue-600" })}
        </div>
        <h3 className="ml-3 text-xl font-semibold text-gray-900">{title}</h3>
      </div>
      <p className="text-gray-600 mb-6">{description}</p>
      <Button
        variant="primary"
        onClick={handleAccess}
        className="w-full"
      >
        Access Portal
      </Button>
    </div>
  );
}

export function PortalAccess() {
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.values(PORTAL_CONFIGS).map(({ title, description, icon, path }) => (
          <PortalButton
            key={path}
            title={title}
            description={description}
            icon={icon}
            path={path}
          />
        ))}
      </div>
    </>
  );
}