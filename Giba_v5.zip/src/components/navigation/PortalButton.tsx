import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, TrendingUp, Folder, BookOpen, Briefcase } from 'lucide-react';
import { Button } from '../ui/Button';
import { useAuth } from '../../contexts/AuthContext';

type PortalType = 'admin' | 'investor' | 'client' | 'student' | 'professional';

interface PortalButtonProps {
  type: PortalType;
  className?: string;
}

export function PortalButton({ type, className = '' }: PortalButtonProps) {
  const navigate = useNavigate();
  const [isReady, setIsReady] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    try {
      const auth = useAuth();
      setIsAuthenticated(auth.isAuthenticated);
      setUser(auth.user);
      setIsReady(true);
    } catch (err) {
      console.error('PortalButton must be used within an AuthProvider.', err);
      setIsReady(false);
    }
  }, []);

  const portalMap = {
    admin: { label: 'Admin Portal', icon: Shield },
    investor: { label: 'Investors Portal', icon: TrendingUp },
    client: { label: 'Client Portal', icon: Folder },
    student: { label: 'Student Portal', icon: BookOpen },
    professional: { label: 'Professional Portal', icon: Briefcase }
  };

  const { label, icon: Icon } = portalMap[type];

  const handleClick = () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: `/${type}` } });
      return;
    }

    if (user?.role !== type) {
      navigate('/unauthorized');
      return;
    }

    navigate(`/${type}`);
  };

  if (!isReady) return null;

  return (
    <Button
      variant="outline"
      size="lg"
      icon={Icon}
      onClick={handleClick}
      className={`px-8 hover-scale bg-white ${className}`}
    >
      {label}
    </Button>
  );
}