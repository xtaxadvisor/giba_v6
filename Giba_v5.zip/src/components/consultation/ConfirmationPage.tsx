import { useEffect } from 'react';

// /components/consultation/ConsultationConfirmation.tsx
export function ConsultationConfirmation() {
  useEffect(() => {
    console.log('Confirmation page loaded');
  }, []);

  return (
    <div className="p-10 text-center">
      <h1 className="text-2xl font-bold">Your consultation has been scheduled!</h1>
      <p className="mt-2 text-gray-600">We’ve sent you a confirmation email with the details.</p>
    </div>
  );
}

export default ConsultationConfirmation;
