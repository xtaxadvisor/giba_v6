import React from 'react';
import { useNavigate } from 'react-router-dom';
// other imports...
export function ConsultationList() {
  const navigate = useNavigate();
  const handleConsultationClick = (consultationId: string) => {
    navigate(`/client/consultation/${consultationId}`);
  };
  // Fetch consultations and map them to a list
  // const { data: consultations, isLoading } = useConsultation();
  // if (isLoading) return <LoadingSpinner />;
  // if (!consultations) return <div>No consultations found</div>;
  // return (
  //   <div>
  //     {consultations.map((consultation) => (
  //       <div key={consultation.id} onClick={() => handleConsultationClick(consultation.id)}>
  //         <h3>{consultation.title}</h3>
  //         <p>{consultation.description}</p>
  //         <p>{new Date(consultation.date).toLocaleDateString()}</p>
  //       </div>
  //     ))}
  //   </div>
  // );
  // Placeholder for the consultation list
  // Function implementation
  return <div>Consultation List Content</div>;
}
// Removed duplicate default export for ConsultationList
import Notifications from '../../components/ui/Notifications'; // Adjust the path as needed

export function BookConsultation() {
  const navigate = useNavigate();

  const handleSubmit = async (values: { [key: string]: any }) => {
    // form submission logic...
    Notifications('Consultation is being scheduled and details will be sent via email.', 'success'); // Ensure Notifications is a callable function
    navigate('/client/consultation/confirmation');
  };

  // rest of the component...
}

// Removed redundant export statement for ConsultationList